#ifndef SYNCHROLISTH
#define SYNCHROLISTH


void getFileNames();
void pipeSendList(int pipe_fd[]);
void pipeReceiveList(int pipe_fd[]);




#endif